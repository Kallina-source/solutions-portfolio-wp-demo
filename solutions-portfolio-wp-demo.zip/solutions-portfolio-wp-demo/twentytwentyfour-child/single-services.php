<?php get_header(); ?>

<main class="wp-block-group">
    <div class="wp-block-group__inner-container">
        <?php while (have_posts()) : the_post(); ?>
            <article class="service-single">
                
                <?php if (has_post_thumbnail()) : ?>
                    <div class="service-featured-image" style="margin-bottom: 2rem;">
                        <?php the_post_thumbnail('large'); ?>
                    </div>
                <?php endif; ?>
                
                <header class="service-header">
                    <h1 class="service-title"><?php the_title(); ?></h1>
                </header>

                <div class="service-content">
                    <?php the_content(); ?>
                </div>

                <div class="service-navigation" style="margin-top: 2rem;">
                    <a href="<?php echo get_post_type_archive_link('services'); ?>" class="back-to-services">
                        ← Back to All Services
                    </a>
                </div>
                
            </article>
        <?php endwhile; ?>
    </div>
</main>

<?php get_footer(); ?>