
<?php
// Silence is golden.
 get_footer(); ?>