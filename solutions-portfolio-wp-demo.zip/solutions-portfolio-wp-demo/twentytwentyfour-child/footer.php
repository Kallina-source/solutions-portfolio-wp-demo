<footer>
    <div class="footer-container">
        <div class="footer-column">
            <h3>Solutions Portfolio</h3>
            <p>About</p>
            <p>Team</p>
            <p>History</p>
            <p>Careers</p>
        </div>
        <div class="footer-column">
            <h3>Privacy</h3>
            <p>Privacy Policy</p>
            <p>Terms and Conditions</p>
            <p>Contact Us</p>
        </div>
        <div class="footer-column">
            <h3>Social</h3>
            <p>Facebook</p>
            <p>Instagram</p>
            <p>Twitter/X</p>
        </div>
    </div>
</footer>
<?php wp_footer(); ?> <!-- This line is important for WordPress -->