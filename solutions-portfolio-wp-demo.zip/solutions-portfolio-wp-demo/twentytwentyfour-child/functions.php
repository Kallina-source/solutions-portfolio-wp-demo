<?php
// Enqueue parent and child theme styles
function twentytwentyfour_child_styles() {
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/style.css');
    wp_enqueue_style('child-style', get_stylesheet_directory_uri() . '/style.css', array('parent-style'));
}
add_action('wp_enqueue_scripts', 'twentytwentyfour_child_styles');

// Register Custom Post Type for Services
function create_services_cpt() {
    $args = array(
        'label' => 'Services',
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'services'), // Ensure the slug is set
        'supports' => array('title', 'editor', 'thumbnail'),
    );
    register_post_type('services', $args);
}
add_action('init', 'create_services_cpt');

// Disable CF7 email sending for demo purposes (XAMPP local development)
add_filter('wpcf7_skip_mail', '__return_true');

// Security: Disable user enumeration
function disable_user_enumeration() {
    if (is_admin() && current_user_can('manage_options')) {
        return;
    }
    
    if (isset($_REQUEST['author']) || preg_match('/\?author=\d+/', $_SERVER['REQUEST_URI'])) {
        wp_redirect(home_url(), 301);
        exit;
    }
}
add_action('init', 'disable_user_enumeration');

// Remove WordPress version from head
remove_action('wp_head', 'wp_generator');
?>