<?php get_header(); ?>

<main class="wp-block-group">
    <div class="wp-block-group__inner-container">
        <header class="page-header">
            <h1 class="page-title">Our Services</h1>
            <p>Explore our comprehensive range of professional services</p>
        </header>

        <?php if (have_posts()) : ?>
            <div class="services-grid">
                <?php while (have_posts()) : the_post(); ?>
                    <article class="service-card">
                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <div class="service-excerpt">
                            <?php the_excerpt(); ?>
                        </div>
                        <a href="<?php the_permalink(); ?>" class="read-more">Learn More</a>
                    </article>
                <?php endwhile; ?>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php get_footer(); ?>